<?php

return [
    __DIR__ . '/Shortlink/routes/route.php',
    __DIR__ . '/CustomForm/routes/route.php',
];
