<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\ModuleProvider::class,
    App\Providers\TelescopeServiceProvider::class,
];
