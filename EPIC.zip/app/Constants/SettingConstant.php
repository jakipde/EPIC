<?php

namespace App\Constants;

class SettingConstant
{
    const SYSTEM = [
        ['key' => 'app_name', 'value' => 'Daisy UI App', 'type' => 'text'],
        ['key' => 'app_logo', 'value' => '', 'type' => 'image'],
    ];
}
