<?php

namespace App\Models;

use App\Models\Default\Model;

class TestModalPage extends Model
{
    protected $fillable = [
        'name',
    ];
}
