## TODO

-   [ ] multilang frontend
-   [ ] move menu to database
-   [ ] upgrade files controller to add models as madia manager
-   [ ] create easy deploy command
-   [ ] generic table editor

## NICE TO CREATE

-   [ ] add rich editor
-   [ ] general table component, a component has filter and search
-   [ ] create unit test to login, logout, manage role, manage user, test api select general table
-   [ ] crud generator with web interface and options to add fields and model
-   [ ] change react\async to spatie\fork
        -> the problem is cant handle async function in webhosting, the main thread is to fast than async proccess
