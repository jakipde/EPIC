import React from 'react'

export default function Spinner() {
    return <span className="loading loading-spinner"></span>
}
